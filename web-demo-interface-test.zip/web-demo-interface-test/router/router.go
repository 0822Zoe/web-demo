package router

import (
	"github.com/gin-gonic/gin"
	"html/template"
	"time"
	"web-demo-interface-test/controller"
	"web-demo-interface-test/log"
	"web-demo-interface-test/middleware"
)

// SetupRouter 设置路由
func SetupRouter() *gin.Engine {
	r := gin.New()

	// 接管Gin的日志
	r.Use(log.GinLogger(log.Logger))

	// 设置时间格式
	r.SetFuncMap(template.FuncMap{
		"timeStr" : func(timeStamp int64) string {
			return time.Unix(timeStamp,0).Format("2023-04-24 12:00:00")
		},
	})

	// 配置模板
	r.LoadHTMLGlob("./templates/*")

	// 登录注册，无需认证
	{
		r.GET("/register",controller.RegisterGET)
		r.POST("/register",controller.RegisterPOST)

		r.GET("/login",controller.LoginGET)
		r.POST("/login",controller.LoginPOST)
	}

	// 需要认证的路由
	{
		routerGroup := r.Group("/api",middleware.BasicAuth())
		routerGroup.GET("/logout",controller.LogoutGet)
		routerGroup.POST("/change",controller.UpdatePOST)
		routerGroup.DELETE("/delete",controller.DeleteGET)
	}
	return r
}
