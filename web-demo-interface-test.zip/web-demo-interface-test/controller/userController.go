package controller

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"time"
	"web-demo-interface-test/dao/userDao"
	"web-demo-interface-test/log"
	"web-demo-interface-test/model/user"
)

func RegisterGET(c *gin.Context)  {
	c.HTML(http.StatusOK,"register.html",gin.H{"title":"注册页"})
}

func RegisterPOST(c *gin.Context)  {
	username := c.PostForm("username")
	password := c.PostForm("password")
	var userModel user.User
	now := time.Now()
	strTime := now.Format("20060102150405")
	userModel.UserId = strTime + username
	userModel.Username = username
	userModel.Password = password
	if username != "" && password != "" {
		userId := user.SelectUser(username)
		// 先查询username是不是已经被注册
		if userId != ""{
			log.Info("注册失败")
			c.HTML(http.StatusConflict,"register.html",gin.H{"title":"注册页","msg":"用户名已经被注册"})
		}else{
			if err := user.InsertUser(&userModel); err == nil{
				log.Info("注册成功")
				LoginGET(c)
			}else {
				log.Error("注册失败")
				c.HTML(http.StatusConflict,"register.html",gin.H{"title":"注册页","msg":"未知错误"})
			}
		}
	}else {
		c.HTML(http.StatusSeeOther,"register.html",gin.H{"title":"注册页","msg":"请输入内容"})
	}
}

func LoginGET(c *gin.Context)  {
	c.HTML(http.StatusOK,"login.html",gin.H{"title":"登录页"})
}

func LoginPOST(c *gin.Context)  {
	var nickname string
	username := c.PostForm("username")
	password := c.PostForm("password")
	user := user.LoginUser(username,password)
	if user.UserId == ""{
		log.Info("登录失败")
		c.HTML(http.StatusBadRequest,"login.html",gin.H{"msg":"用户名或密码输入错误"})
	}
	err := userDao.QueryRowDB(&nickname,"select nickname from user_info_table where userId=?",user.UserId)
	if err != nil{
		log.Info("登录失败")
		c.HTML(http.StatusBadRequest,"login.html",gin.H{"msg":"未查询到昵称"})
	}
	log.Info("登录成功")
	c.HTML(http.StatusOK,"info.html",gin.H{"nickname":nickname})
}

func DeleteGET(c *gin.Context)  {
	//获取session，然后删除，使session过期
	_, err := user.DeleteUser("user")
	if err != nil {
		return 
	}
	c.HTML(http.StatusOK,"login.html",gin.H{"title":"登录页"})
}

func UpdatePOST(c *gin.Context)  {
	var info *user.Info
	nickname := c.PostForm("nickname")
	password := c.PostForm("password")
	newPassword := c.PostForm("newPassword")
	reNewPassword := c.PostForm("reNewPassword")
	if nickname == ""{
		//nickname从session获取
	}
	if password != ""{
		
	}
	if newPassword != reNewPassword{
		
	}
	info.NickName = nickname
	info.Password = newPassword
	user.UpdateInfo(info)
}

func LogoutGet(c *gin.Context)  {
	//获取session使过期

	c.HTML(http.StatusOK,"login.html",gin.H{"title":"登录页"})
}